package com.example.channuoiheo.service;

import com.example.channuoiheo.model.Origin;

public interface IOriginService extends IGenerateService<Origin> {
}
