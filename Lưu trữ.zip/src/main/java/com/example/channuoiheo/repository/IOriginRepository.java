package com.example.channuoiheo.repository;

import com.example.channuoiheo.model.Origin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IOriginRepository extends JpaRepository<Origin, Integer> {
}
